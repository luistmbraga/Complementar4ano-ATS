var matrix = [[0,0,1,0,1,0,0],[0,0,0,0,0,0,0],[0,6,0,5,0,0,0],[0,0,0,0,0,0,0],[0,0,1,1,0,1,1],[0,6,4,4,0,0,0],[0,2,0,1,0,1,0]];
var packages = [{
"name": " ", "color": " #3182bd"
}
,{
"name": " Utils", "color": " #6baed6"
}
,{
"name": " Model", "color": " #9ecae1"
}
,{
"name": " Exceptions", "color": " #c6dbef"
}
,{
"name": " Controller", "color": " #e6550d"
}
,{
"name": " View.ViewModel", "color": " #fd8d3c"
}
,{
"name": " View", "color": " #fdae6b"
}
];
