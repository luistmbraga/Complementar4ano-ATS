package View;

interface ITable {
    String toString();
}
