package Exceptions;

public class InvalidUserException extends Exception {
    private static final long serialVersionUID = 8278089548937605185L;
}
