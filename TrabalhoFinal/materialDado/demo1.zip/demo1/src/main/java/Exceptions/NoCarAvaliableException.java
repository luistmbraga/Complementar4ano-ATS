package Exceptions;

public class NoCarAvaliableException extends Exception {
    private static final long serialVersionUID = 2398925856524551940L;
}
