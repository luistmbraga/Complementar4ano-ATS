package Exceptions;

public class InvalidRatingException extends Exception {
    private static final long serialVersionUID = -8610627339190443198L;
}
