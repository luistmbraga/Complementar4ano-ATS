package Exceptions;

public class WrongPasswordExecption extends Exception {
    private static final long serialVersionUID = 3670046658149861953L;
}
