package Exceptions;

public class InvalidNumberOfArgumentsException extends Throwable {
    private static final long serialVersionUID = -4608391217465248554L;
}
