package Exceptions;

public class InvalidNewRentalException extends Throwable {
    private static final long serialVersionUID = 4378462538950802892L;
}
