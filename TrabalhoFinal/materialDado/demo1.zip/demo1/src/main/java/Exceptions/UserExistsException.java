package Exceptions;

public class UserExistsException extends Exception {

    private static final long serialVersionUID = -6024658726177143223L;
}
