package Exceptions;

public class UnknownCarTypeException extends Exception {
    private static final long serialVersionUID = -9149988756245567338L;
}
