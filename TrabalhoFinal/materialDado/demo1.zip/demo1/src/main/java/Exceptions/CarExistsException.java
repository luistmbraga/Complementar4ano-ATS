package Exceptions;

public class CarExistsException extends Exception {
    private static final long serialVersionUID = -738776382906015444L;
}
