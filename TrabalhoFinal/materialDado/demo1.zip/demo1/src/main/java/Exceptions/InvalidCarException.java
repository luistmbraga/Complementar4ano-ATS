package Exceptions;

public class InvalidCarException extends Exception {
    private static final long serialVersionUID = -3711612803152603142L;
}
