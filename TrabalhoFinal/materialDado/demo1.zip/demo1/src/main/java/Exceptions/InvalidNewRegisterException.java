package Exceptions;

public class InvalidNewRegisterException extends Exception {
    private static final long serialVersionUID = -6502164337050657240L;
}
