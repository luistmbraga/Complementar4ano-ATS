
/**
 * Veiculos sem disponibilidade.
 * 
 * 
 * @version (número de versão ou data)
 */
public class VeiculoIndisponivelException extends Exception
{
    public VeiculoIndisponivelException (String s){
        super(s);
    }
}
