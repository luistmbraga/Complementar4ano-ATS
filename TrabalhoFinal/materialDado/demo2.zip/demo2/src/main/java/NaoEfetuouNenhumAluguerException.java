
/**
 * Não existem alugueres.
 * 
 * 
 * @version (número de versão ou data)
 */
public class NaoEfetuouNenhumAluguerException extends Exception 
{
    public NaoEfetuouNenhumAluguerException(String s){
        super(s);
    } 
}
